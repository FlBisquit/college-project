from django.db import models
from uuid import uuid4
from users.models import User
from random import randint


def generate_uuid():
    return str(uuid4())


def unic_number():
    return f"{randint(0, 999999):06d}"


class Chat(models.Model):
    id = models.CharField(
        max_length=36,
        primary_key=True,
        default=generate_uuid
    )
    number = models.CharField(
        max_length=6,
        default=unic_number
    )
    owner = models.ForeignKey(
        User,
        on_delete=models.CASCADE
    )
    max_chaters = models.IntegerField(default=12)
    done = models.BooleanField(default=False)
    started = models.BooleanField(default=False)


class ChatData(models.Model):
    owner = models.ForeignKey(
        Chat,
        on_delete=models.CASCADE
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE
    )
    data = models.JSONField(default=dict)
