from .models import Chat, Message
from django.contrib.auth.models import AnonymousUser

async def receive(self, text_data):
    text_data_json = json.loads(text_data)
    message = text_data_json['message']
    chat = await database_sync_to_async(Chat.objects.get)(id=self.chat_id)
    user = self.scope["user"]
    if user.is_anonymous:
        user = await database_sync_to_async(User.objects.get)(username="guest")  # или как-то обрабатываем
    await database_sync_to_async(Message.objects.create)(
        chat=chat,
        author=user,
        text=message
    )

    await self.channel_layer.group_send(
        self.room_group_name,
        {
            'type': 'chat_message',
            'message': message
        }
    )
