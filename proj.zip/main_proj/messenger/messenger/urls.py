urlpatterns = [
    path('admin/', admin.site.urls),

    path('', users_index),
    path('users/', users_main),
    path('users/register', users_register),
    path('users/auth', users_auth),
    path('users/get/<str:user_id>', get_user_by_id),
    path('chatting/', include('chatting.urls')),
]
